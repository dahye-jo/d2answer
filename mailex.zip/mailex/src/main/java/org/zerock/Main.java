package org.zerock;

import org.zerock.mail.MailConfig;
import org.zerock.mail.MailSender;

public class Main {

    public static void main(String[] args) {

        MailConfig mailConfig = new MailConfig("kangckck23@gmail.com","qxrbllfuxtdwehvh");

        MailSender mailSender = new MailSender(mailConfig);

        mailSender.sendMail();

    }
}
