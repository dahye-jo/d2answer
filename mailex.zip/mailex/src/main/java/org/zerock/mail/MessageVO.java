package org.zerock.mail;

public class MessageVO {
}
